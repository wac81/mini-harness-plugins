"""Date utilities for last30days skill."""

from datetime import date, datetime, timedelta, timezone
import math
import re
from typing import Optional, Tuple


def x_date_filters(from_date: str, to_date: str) -> str:
    """Translate an inclusive research window to X search operators."""
    filters = f"since:{from_date}"
    end = date.fromisoformat(to_date)
    if end != date.max:
        filters += f" until:{(end + timedelta(days=1)).isoformat()}"
    return filters


def parse_as_of_date(as_of_date: Optional[str]) -> Optional[str]:
    """Validate and normalize an --as-of date.

    Args:
        as_of_date: Date string in YYYY-MM-DD format.

    Returns:
        Normalized YYYY-MM-DD string, or None when no date was provided.

    Raises:
        ValueError: If the date is not in YYYY-MM-DD format.
    """
    if as_of_date is None:
        return None

    if not as_of_date.strip():
        raise ValueError("--as-of must be in YYYY-MM-DD format.")

    try:
        parsed = datetime.strptime(as_of_date, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError(
            f"Invalid --as-of date: {as_of_date}. Expected YYYY-MM-DD."
        ) from exc

    return parsed.isoformat()


def get_date_range(days: int = 30, as_of_date: Optional[str] = None) -> Tuple[str, str]:
    """Get the date range for the last N days.

    When as_of_date is provided, the range ends at that date instead of today.

    Args:
        days: Number of days to look back.
        as_of_date: Optional end date in YYYY-MM-DD format.

    Returns:
        Tuple of (from_date, to_date) as YYYY-MM-DD strings.
    """
    normalized_as_of = parse_as_of_date(as_of_date)

    if normalized_as_of:
        to_date = datetime.strptime(normalized_as_of, "%Y-%m-%d").date()
    else:
        to_date = datetime.now(timezone.utc).date()

    from_date = to_date - timedelta(days=days)
    return from_date.isoformat(), to_date.isoformat()


def _local_now() -> datetime:
    """The reader's clock, with its UTC offset."""
    return datetime.now().astimezone()


def reader_end_date(to_date: str, now: Optional[datetime] = None) -> date:
    """A window's end date as the reader's calendar has it.

    The window ends on the UTC date so queries and item filters lose no
    post. West of UTC that date is tomorrow for part of every day (5pm in
    Los Angeles on Nov 10 is already Nov 11 in UTC), and "to Nov 11" reads
    as a window that runs into the future. A window that ends on today's UTC
    date is shown ending on the reader's own date when that is earlier. A
    window that ends on any other day (``--as-of``) is shown as it is.
    ``now`` is an aware datetime; tests pass one.
    """
    end = date.fromisoformat(to_date)
    now = now or _local_now()
    try:
        utc_date = now.astimezone(timezone.utc).date()
    except OverflowError:
        return end
    if end == utc_date and now.date() < end:
        return now.date()
    return end


def is_today(value: str, now: Optional[datetime] = None) -> bool:
    """Whether a YYYY-MM-DD date is today in UTC or on the reader's calendar.

    West of UTC the two calendars differ for part of every day, and a date
    that is today on either one is a live window. ``now`` is an aware
    datetime.
    """
    day = date.fromisoformat(value)
    now = now or _local_now()
    try:
        utc_date = now.astimezone(timezone.utc).date()
    except OverflowError:
        return day == now.date()
    return day in (utc_date, now.date())


def format_window(from_date: str, to_date: str, now: Optional[datetime] = None) -> str:
    """Render an ISO date window for readers, e.g. ``Oct 11 to Nov 10, 2026``.

    The year is printed once when both dates share it and on both dates when
    the window crosses a year boundary. The end is the reader's date
    (``reader_end_date``), never tomorrow.
    """
    end = reader_end_date(to_date, now)
    start = min(date.fromisoformat(from_date), end)
    start_text = f"{start:%b} {start.day}"
    if start.year != end.year:
        start_text += f", {start.year}"
    return f"{start_text} to {end:%b} {end.day}, {end.year}"


# Epoch-second guard for ambiguous string parsing: 9-10 integer digits
# (1973-03-03 to 2286-11-20), so compact YYYYMMDD dates (8 digits), bare
# 4-digit years, "0", and huge numeric IDs are never misread as 1970 epochs.
_UNIX_SECONDS_RE = re.compile(r"^\d{9,10}(?:\.\d+)?$")
_MIN_UNIX_SECONDS = 100_000_000.0
_MAX_UNIX_SECONDS = 10_000_000_000.0


def parse_date(date_str: Optional[str]) -> Optional[datetime]:
    """Parse a date string in various formats.

    Supports: YYYY-MM-DD, YYYYMMDD, ISO 8601 (with Z, offsets, fractional
    seconds, or space separator), and plausible Unix epoch-second timestamps.
    """
    if date_str is None or isinstance(date_str, bool):
        return None

    if isinstance(date_str, (int, float)):
        try:
            ts = float(date_str)
            if not math.isfinite(ts) or not (_MIN_UNIX_SECONDS <= ts < _MAX_UNIX_SECONDS):
                return None
            return datetime.fromtimestamp(ts, tz=timezone.utc)
        except (ValueError, TypeError, OverflowError, OSError):
            return None

    if not isinstance(date_str, str):
        return None

    cleaned = date_str.strip()
    if not cleaned:
        return None

    # Plausible Unix epoch seconds (e.g. Reddit created_utc as string)
    if _UNIX_SECONDS_RE.match(cleaned):
        try:
            ts = float(cleaned)
            if math.isfinite(ts) and _MIN_UNIX_SECONDS <= ts < _MAX_UNIX_SECONDS:
                return datetime.fromtimestamp(ts, tz=timezone.utc)
        except (ValueError, TypeError, OverflowError, OSError):
            return None

    # ISO 8601 (Python 3.12 handles YYYY-MM-DD, YYYYMMDD, Z, ±HH:MM, ±HHMM,
    # naive/aware fractional seconds, and space-separated date/time)
    try:
        dt = datetime.fromisoformat(cleaned)
        if dt.tzinfo is not None:
            return dt.astimezone(timezone.utc)
        return dt.replace(tzinfo=timezone.utc)
    except (ValueError, OverflowError):
        return None


def timestamp_to_date(ts: Optional[float]) -> Optional[str]:
    """Convert Unix timestamp to YYYY-MM-DD string."""
    if ts is None or isinstance(ts, bool):
        return None
    if not isinstance(ts, (int, float)):
        return None
    try:
        ts_f = float(ts)
        if not math.isfinite(ts_f):
            return None
        dt = datetime.fromtimestamp(ts_f, tz=timezone.utc)
        return dt.date().isoformat()
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def get_date_confidence(date_str: Optional[str], from_date: str, to_date: str) -> str:
    """Determine confidence level for a date.

    Args:
        date_str: The date to check (YYYY-MM-DD or None)
        from_date: Start of valid range (YYYY-MM-DD)
        to_date: End of valid range (YYYY-MM-DD)

    Returns:
        'high', 'med', or 'low'
    """
    if not date_str:
        return 'low'

    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d").date()
        start = datetime.strptime(from_date, "%Y-%m-%d").date()
        end = datetime.strptime(to_date, "%Y-%m-%d").date()

        return 'high' if start <= dt <= end else 'low'
    except ValueError:
        return 'low'


def days_ago(date_str: Optional[str], reference_date: Optional[str] = None) -> Optional[int]:
    """Calculate how many days before the reference date a date is.

    If reference_date is None, use real today for backward compatibility.
    Returns None if date is invalid or missing.
    """
    if not date_str:
        return None

    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d").date()
        if reference_date:
            today = datetime.strptime(reference_date, "%Y-%m-%d").date()
        else:
            today = datetime.now(timezone.utc).date()
        delta = today - dt
        return delta.days
    except ValueError:
        return None


def recency_score(
    date_str: Optional[str],
    max_days: int = 30,
    reference_date: Optional[str] = None,
) -> int:
    """Calculate recency score (0-100).

    0 days before reference_date = 100, max_days before reference_date = 0.
    If reference_date is None, use real today for backward compatibility.
    """
    age = days_ago(date_str, reference_date=reference_date)
    if age is None:
        return 0

    if age < 0:
        return 100
    if age >= max_days:
        return 0

    return int(100 * (1 - age / max_days))
