"""Bird X search client for the v3.0.0 last30days pipeline.

Uses a vendored subset of @steipete/bird v0.8.0 (MIT License) to search X
via Twitter's GraphQL API. No external `bird` CLI binary needed - just Node.js.
See scripts/lib/vendor/bird-search/package.json for authoritative version.
"""

import json
import os
import shutil
import sys
import threading
import time
from pathlib import Path

from . import env, health, http, log, subproc
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from .relevance import token_overlap_relevance as _compute_relevance

# How many times to retry the bird-search subprocess when stdout is non-JSON
# (typically an HTML anti-bot interstitial from Twitter's edge).
MAX_JSON_DECODE_RETRIES = 2
JSON_DECODE_RETRY_DELAY = 5.0  # seconds between retry attempts


def _leading_mentions(text: str) -> list:
    """Leading-run @mention parse, shared with other X-shaped sources (xquik).

    Thin wrapper over ``query.leading_mentions`` so bird and xquik share one
    implementation; kept here for existing call sites and tests.
    """
    from .query import leading_mentions
    return leading_mentions(text)


def _first_of(*values):
    """Return first value that is not None."""
    for v in values:
        if v is not None:
            return v
    return None

# Path to the vendored bird-search wrapper
_BIRD_SEARCH_MJS = Path(__file__).parent / "vendor" / "bird-search" / "bird-search.mjs"

# Depth configurations: number of results to request
DEPTH_CONFIG = {
    "quick": 12,
    "default": 30,
    "deep": 60,
}

# Module-level credentials injected from .env config
_credentials: Dict[str, str] = {}
_SECRET_ENV_NAMES = ("AUTH_TOKEN", "CT0", "TWITTER_AUTH_TOKEN", "TWITTER_CT0")
_seen_secrets: set[str] = set()
_secrets_lock = threading.Lock()


def _secret_variants(value: Optional[str]) -> List[str]:
    if not isinstance(value, str) or not value:
        return []
    variants: List[str] = []
    for candidate in (value, value.strip()):
        # Short values would match too much ordinary text to be worth it.
        if len(candidate) >= 8:
            variants.append(candidate)
            escaped = json.dumps(candidate)[1:-1]
            if escaped != candidate and len(escaped) >= 8:
                variants.append(escaped)
    return variants


def _record_secret(value: Optional[str]) -> None:
    variants = _secret_variants(value)
    if not variants:
        return
    with _secrets_lock:
        _seen_secrets.update(variants)

# The vendored bird-search client reads exactly this env surface, and the
# node subprocess it spawns needs the node-runtime env (platform, locale,
# TLS/proxy config) to run in every environment it runs in today. Ambient
# BIRD_* vars pass through as well. Everything else in os.environ - unrelated
# API keys, tokens, .env contents - must not reach the scan-excluded vendored
# client (issue #1063). Mirrors the platform-var surface grok_x keeps for its
# node child (grok_x._subprocess_env).
_SUBPROCESS_ENV_ALLOWLIST = (
    # Runtime / platform vars the node subprocess needs (mirrors grok_x)
    "PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SystemRoot",
    "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "SystemDrive", "COMSPEC",
    "PATHEXT", "TEMP", "TMP",
    # Node TLS / proxy / CA config for custom-CA and proxied environments
    "NODE_ENV", "NODE_OPTIONS", "NODE_EXTRA_CA_CERTS",
    "NODE_TLS_REJECT_UNAUTHORIZED", "NODE_USE_ENV_PROXY",
    "SSL_CERT_FILE", "SSL_CERT_DIR", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY",
    "http_proxy", "https_proxy", "no_proxy",
    # X session cookies the vendored client reads from the environment
    "AUTH_TOKEN", "CT0", "TWITTER_AUTH_TOKEN", "TWITTER_CT0",
    # Browser-cookie consent/disable flags the client reads (cookies.js)
    "LAST30DAYS_DISABLE_BROWSER_COOKIES", "FROM_BROWSER", "BROWSER_CONSENT",
)

_BIRD_CAPTURE_LIMIT_BYTES = 8 * 1024 * 1024


def _set_credentials_only(auth_token: Optional[str], ct0: Optional[str]) -> None:
    """Update injected AUTH_TOKEN/CT0 without altering browser-failover state."""
    _record_secret(_credentials.get('AUTH_TOKEN'))
    _record_secret(_credentials.get('CT0'))
    if auth_token:
        _record_secret(auth_token)
        _credentials['AUTH_TOKEN'] = auth_token
    else:
        _credentials.pop('AUTH_TOKEN', None)
    if ct0:
        _record_secret(ct0)
        _credentials['CT0'] = ct0
    else:
        _credentials.pop('CT0', None)


def set_credentials(auth_token: Optional[str], ct0: Optional[str]):
    """Inject AUTH_TOKEN/CT0 from .env config so Node subprocesses can use them."""
    global _session_browser, _next_session
    with _session_lock:
        _set_credentials_only(auth_token, ct0)
        _session_browser = None
        _next_session = None


# Browser-session failover: the browser that supplied the current session and
# a callback that extracts the next browser's session after X rejects it.
_session_browser: Optional[str] = None
_next_session: Optional[Any] = None
_session_lock = threading.Lock()


def set_session_failover(browser: Optional[str], next_session: Optional[Any]) -> None:
    """Register where the injected session came from and how to replace it.

    ``next_session`` takes no arguments and returns ``(auth_token, ct0,
    browser)`` for the next browser's session, or None when none is left.
    """
    global _session_browser, _next_session
    with _session_lock:
        _session_browser = browser
        _next_session = next_session


# X answers a search made with an expired or revoked session either with a
# 401 "Could not authenticate you" (code 32) or, for the POST SearchTimeline
# call, with HTTP 200 and a GraphQL "Internal server error" on the timeline.
_SESSION_REJECTED_MARKERS = ("could not authenticate", "http 401", "\"code\":32")
_SESSION_SUSPECT_MARKERS = ("internal server error",)


def _session_rejected(error: str) -> bool:
    text = error.lower()
    return any(m in text for m in _SESSION_REJECTED_MARKERS)


def _session_suspect(error: str) -> bool:
    text = error.lower()
    return _session_rejected(error) or any(m in text for m in _SESSION_SUSPECT_MARKERS)


def _has_injected_credentials() -> bool:
    """Return True when both X session cookies were injected from config."""
    return bool(_credentials.get('AUTH_TOKEN') and _credentials.get('CT0'))


def _has_process_credentials() -> bool:
    """Return True when AUTH_TOKEN/CT0 are present in process env."""
    return bool(env.read_secret_env("AUTH_TOKEN") and env.read_secret_env("CT0"))


def _subprocess_env() -> Dict[str, str]:
    """Build env dict for Node subprocesses, merging injected credentials.

    The child env is limited to the vendored client's env surface (see
    ``_SUBPROCESS_ENV_ALLOWLIST``) plus injected credentials, so unrelated
    ambient secrets never reach scan-excluded vendored code (issue #1063).
    The ambient-credential lane behaves exactly as before.
    """
    env = {
        name: os.environ[name]
        for name in _SUBPROCESS_ENV_ALLOWLIST
        if name in os.environ
    }
    env.update({
        key: value for key, value in os.environ.items()
        if key.startswith("BIRD_")
    })
    env.update(_credentials)
    for secret_name in _SECRET_ENV_NAMES:
        _record_secret(env.get(secret_name))
    # Hard-disable browser-cookie fallback so normal pipeline runs never hit
    # Safari/Chrome Keychain prompts during source detection or search.
    env["BIRD_DISABLE_BROWSER_COOKIES"] = "1"
    return env


def _log(msg: str):
    log.source_log("Bird", msg, tty_only=False)


def _scrub_credentials(text: str) -> str:
    """Redact X session cookie values from subprocess output.

    A failure reason built from bird-search's stderr reaches the run's
    ``source_status`` detail, which is rendered in the report and returned by
    ``--emit=json``. The vendored client receives AUTH_TOKEN/CT0 in its
    environment, so an error message that echoes a rejected cookie would
    otherwise carry it into user-facing output. Log lines get the same
    treatment because stderr is captured in agent harnesses.
    """
    if not text:
        return "" if text is None else text
    scrubbed = str(text)
    candidates: set[str] = set()
    for name in _SECRET_ENV_NAMES:
        cred_val = _credentials.get(name)
        if cred_val:
            _record_secret(cred_val)
            candidates.update(_secret_variants(cred_val))
        env_val = os.environ.get(name)
        if env_val:
            _record_secret(env_val)
            candidates.update(_secret_variants(env_val))
    with _secrets_lock:
        candidates.update(_seen_secrets)
    for secret in sorted(candidates, key=len, reverse=True):
        scrubbed = scrubbed.replace(secret, "<redacted>")
    return scrubbed


def classify_run_failure(detail: str) -> str:
    """Map Bird's subprocess-only failure shapes to run outcome states."""
    text = detail.lower()
    if any(marker in text for marker in ("interstitial", "non-json", "invalid json")):
        return health.SCHEMA_DRIFT
    if any(
        marker in text
        for marker in (
            "cookie expired", "expired cookie", "unauthorized", "forbidden",
            "login required", "could not authenticate", "session rejected",
        )
    ):
        return health.AUTH_FAILED
    return http.classify_failure(message=detail)


def _extract_core_subject(topic: str) -> str:
    """Extract core subject from verbose query for X search.

    X search is literal keyword AND matching — all words must appear.
    Aggressively strip question/meta/research words to keep only the
    core product/concept name (max 5 words).
    """
    from .query import extract_core_subject
    return extract_core_subject(topic, max_words=5, strip_suffixes=True)


_PHRASE_MARKER = "\x00"
_QUERY_SEPARATORS = str.maketrans({char: " " for char in "“”()[]{}\\" + _PHRASE_MARKER})

# Use the public X recent-search query budget for Bird's SearchTimeline queries.
MAX_QUERY_CHARS = 512


def _topic_query_terms(topic: str) -> list[str]:
    """Return safe keywords and whole quoted phrases for the Bird compiler."""
    sections = topic.split('"')
    if len(sections) % 2 == 0:
        sections = [" ".join(sections)]
    terms = []
    for index, section in enumerate(sections):
        if index % 2:
            phrase = section.replace(_PHRASE_MARKER, " ").strip()
            if phrase:
                terms.append(f'"{phrase}"')
            continue
        for token in section.translate(_QUERY_SEPARATORS).split():
            word = token.strip("'‘’")
            if word.endswith(":") and word.count(":") == 1:
                word = word[:-1]
            if not word or ":" in word or word.startswith("-"):
                continue
            if word.upper() in ("AND", "OR"):
                continue
            terms.append(word)
    return terms


def _fit_query(terms: list[str], filters: str, *, disjunction: bool = False) -> str:
    """Fit complete terms and the date filters without emitting a window-only query."""
    prefix = "(" if disjunction else ""
    suffix = f") {filters}" if disjunction else f" {filters}"
    separator = " OR " if disjunction else " "
    length = len(prefix) + len(suffix)
    if not disjunction and terms and terms[0].startswith('"'):
        if len(terms[0]) + terms[0].count("\\") + length > MAX_QUERY_CHARS:
            terms = _topic_query_terms(terms[0][1:-1]) + terms[1:]

    fitted = []
    for term in terms:
        if term.startswith('"'):
            term = term.replace("\\", "\\\\")
        added = len(term) + (len(separator) if fitted else 0)
        if length + added > MAX_QUERY_CHARS:
            if disjunction:
                continue
            break
        fitted.append(term)
        length += added
    if not fitted:
        return ""
    return f"{prefix}{separator.join(fitted)}{suffix}"


def _date_filters(from_date: str, to_date: Optional[str] = None) -> str:
    filters = f"since:{from_date}"
    if to_date is not None:
        end = date.fromisoformat(to_date)
        if end == date.max:
            # No supported post date lies beyond this inclusive upper bound.
            return filters
        # The research window includes to_date; X's until bound is exclusive.
        until = end + timedelta(days=1)
        filters += f" until:{until.isoformat()}"
    return filters


def build_topic_query(
    topic: str, from_date: str, to_date: Optional[str] = None
) -> str:
    """Build a bounded topic query with literal phrases and engine-owned dates."""
    return _fit_query(_topic_query_terms(topic), _date_filters(from_date, to_date))


def is_bird_installed() -> bool:
    """Check if vendored Bird search module is available.

    Returns:
        True if bird-search.mjs exists and Node.js is in PATH.
    """
    if not _BIRD_SEARCH_MJS.exists():
        return False
    return shutil.which("node") is not None


def is_bird_authenticated() -> Optional[str]:
    """Check if explicit X credentials are available.

    Returns:
        Auth source string if authenticated, None otherwise.
    """
    if not is_bird_installed():
        return None

    if _has_injected_credentials():
        return "env AUTH_TOKEN"
    if _has_process_credentials():
        return "env AUTH_TOKEN"
    return None


_probe_cache: Optional[Optional[bool]] = "unset"  # "unset" | True | False | None


def probe_works(timeout: int = 8) -> Optional[bool]:
    """Cheap runtime check that X auth actually returns data.

    Returns True when a 1-result probe comes back without an error, False on a
    clear failure (auth error / generic search failure), and None when the
    result is inconclusive (network timeout) so callers can fail open and keep
    the static credential-presence status rather than reporting a false-down.
    Cached per process so repeated diagnose calls don't re-probe.
    """
    global _probe_cache
    if _probe_cache != "unset":
        return _probe_cache  # type: ignore[return-value]
    if not (_has_injected_credentials() or _has_process_credentials()):
        _probe_cache = False
        return False
    from datetime import datetime, timedelta, timezone
    since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%d")
    # @x (the platform's own account) posts frequently, so a no-error response
    # means auth works even if this particular window is quiet.
    resp = _run_bird_search(f"from:x since:{since}", count=1, timeout=timeout)
    if isinstance(resp, dict) and resp.get("error"):
        err = str(resp.get("error")).lower()
        if "timed out" in err or "timeout" in err:
            _probe_cache = None  # inconclusive — don't downgrade on a transient timeout
            return None
        _probe_cache = False
        return False
    _probe_cache = True
    return True


def check_npm_available() -> bool:
    """Check if npm is available (kept for API compatibility).

    Returns:
        True if 'npm' command is available in PATH, False otherwise.
    """
    return shutil.which("npm") is not None


def install_bird() -> Tuple[bool, str]:
    """No-op. Bird search is vendored in v3.0.0, no installation needed.

    Returns:
        Tuple of (success, message).
    """
    if is_bird_installed():
        return True, "Bird search is bundled with /last30days v3.0.0 - no installation needed."
    if not shutil.which("node"):
        return False, "Node.js 22+ is required for X search. Install Node.js first."
    return False, f"Vendored bird-search.mjs not found at {_BIRD_SEARCH_MJS}"


def get_bird_status() -> Dict[str, Any]:
    """Get comprehensive Bird search status.

    Returns:
        Dict with keys: installed, authenticated, username, can_install
    """
    installed = is_bird_installed()
    auth_source = is_bird_authenticated() if installed else None

    return {
        "installed": installed,
        "authenticated": auth_source is not None,
        "username": auth_source,  # Now returns auth source (e.g., "Safari", "env AUTH_TOKEN")
        "can_install": True,  # Always vendored in v3.0.0
    }


_MAX_NODE_TIMEOUT_MS = 2_147_483_647


def _bird_timeout_ms(timeout: int, deadline: Optional[float]) -> int:
    """Compute Node --timeout-ms with headroom before Python kills the child."""
    budget_ms = max(1, int(timeout * 1000))
    if deadline is not None:
        remaining_ms = max(1, int((deadline - time.monotonic()) * 1000))
        budget_ms = min(budget_ms, remaining_ms)
    # Leave flush headroom so Node self-aborts and writes partial JSON to stdout
    # before subproc.run_with_timeout terminates the child process.
    if budget_ms > 1000:
        headroom_ms = min(1500, budget_ms // 5)
        budget_ms = max(250, budget_ms - headroom_ms)
    elif budget_ms > 250:
        budget_ms = max(1, budget_ms - budget_ms // 5)
    return min(budget_ms, _MAX_NODE_TIMEOUT_MS)


def _invoke_bird_subprocess(
    query: str,
    count: int,
    timeout: int,
    top: bool = False,
    *,
    deadline: Optional[float] = None,
    cancel: Any = None,
):
    """Invoke the vendored bird-search.mjs subprocess once.

    Returns (result, error_dict). If error_dict is non-None, treat it as the
    final result and do not retry — those errors are terminal (timeout,
    spawn failure). If error_dict is None, the subprocess ran to completion
    and `result` is the SubprocResult; the caller decides whether to retry
    based on the result.stdout content.
    """
    timeout_ms = _bird_timeout_ms(timeout, deadline)
    cmd = [
        "node", str(_BIRD_SEARCH_MJS),
        "--count", str(count),
        "--timeout-ms", str(timeout_ms),
        "--json",
    ]
    if top:
        cmd.append("--top")
    cmd.extend(["--", query])

    try:
        result = subproc.run_with_timeout(
            cmd,
            timeout=timeout,
            env=_subprocess_env(),
            cancel=cancel,
            deadline_monotonic=deadline,
            capture_limit_bytes=_BIRD_CAPTURE_LIMIT_BYTES,
        )
    except subproc.SubprocTimeout:
        if cancel is not None and cancel.is_set():
            return None, {"error": "bird: research cancelled", "items": []}
        return None, {"error": f"Search timed out after {timeout}s", "items": []}
    except Exception as e:
        return None, {"error": _scrub_credentials(str(e)), "items": []}

    return result, None


def _invalid_json_error(
    attempts: int,
    decode_error: Optional[str],
    budget_exhausted: bool = False,
) -> Dict[str, Any]:
    noun = "attempt" if attempts == 1 else "attempts"
    skipped = ", retry skipped: chain budget exhausted" if budget_exhausted else ""
    return {
        "error": (
            f"Invalid JSON response after {attempts} {noun}{skipped} "
            f"(likely Twitter anti-bot interstitial): {decode_error}"
        ),
        "items": [],
    }


def _usable_item_count(response: Any) -> int:
    """Count raw tweets in a Bird response that parse_bird_response will keep."""
    if isinstance(response, list):
        raw_items = response
    elif isinstance(response, dict):
        raw_items = response.get("items", response.get("tweets", []))
    else:
        return 0
    if not isinstance(raw_items, list):
        return 0
    count = 0
    for tweet in raw_items:
        if not isinstance(tweet, dict):
            continue
        url = tweet.get("permanent_url") or tweet.get("url", "")
        if not url and tweet.get("id"):
            author = tweet.get("author") or tweet.get("user") or {}
            if isinstance(author, dict) and (author.get("username") or author.get("screen_name")):
                url = "ok"
        if url:
            count += 1
    return count


def _run_bird_search(
    query: str,
    count: int,
    timeout: int,
    deadline: Optional[float] = None,
    cancel: Any = None,
    top: bool = False,
) -> Dict[str, Any]:
    """Run one search, moving to the next browser's X session on rejection.

    When X rejects the injected browser session (see ``_session_suspect``)
    and another configured browser holds a different complete session, the
    search is retried with that session, which then stays injected for the
    rest of the run. Without a usable alternate, the error names the browser
    whose session failed so the report says what to fix.
    """
    best_partial: Optional[Dict[str, Any]] = None
    best_partial_count = 0

    def _keep_best_partial(
        current: Dict[str, Any], current_error: str, current_count: int
    ) -> Dict[str, Any]:
        if best_partial is None or current_count >= best_partial_count:
            return current
        if current_error:
            return {**best_partial, "error": _scrub_credentials(current_error)}
        return best_partial

    while True:
        started_with = _credentials.get('AUTH_TOKEN')
        response = _run_bird_search_once(
            query, count, timeout, deadline=deadline, cancel=cancel, top=top,
        )
        error = str(response.get("error") or "") if isinstance(response, dict) else ""
        usable_count = _usable_item_count(response)
        if not error or not _session_suspect(error):
            if best_partial is not None and usable_count < best_partial_count and (error or usable_count == 0):
                return _keep_best_partial(response, error, usable_count)
            return response
        if usable_count > best_partial_count:
            best_partial = response
            best_partial_count = usable_count
        if cancel is not None and cancel.is_set():
            return _keep_best_partial(response, error, usable_count)
        failed_browser = _session_browser
        # Never start browser reads (possible Keychain prompts) once the
        # search budget can no longer fit a retry.
        if deadline is not None and _clamped_bird_timeout(timeout, deadline) is None:
            chosen = _keep_best_partial(response, error, usable_count)
            return _annotate_session_error(chosen, error, failed_browser)
        wait = -1 if deadline is None else max(0.0, deadline - time.monotonic())
        if not _session_lock.acquire(timeout=wait):
            chosen = _keep_best_partial(response, error, usable_count)
            return _annotate_session_error(chosen, error, failed_browser)
        try:
            if _credentials.get('AUTH_TOKEN') != started_with:
                switched = True  # another search already moved to a new session
            else:
                switched = False
                failed_browser = _session_browser
                nxt = (
                    _next_session(deadline=deadline, cancel=cancel)
                    if _next_session is not None else None
                )
                if nxt:
                    auth_token, ct0, browser = nxt
                    _set_credentials_only(auth_token, ct0)
                    _session_browser_update(browser)
                    log.source_log(
                        "X/bird",
                        f"X rejected the {failed_browser} session; retrying with {browser} cookies",
                        tty_only=False,
                    )
                    switched = True
        finally:
            _session_lock.release()
        if switched:
            timeout = _clamped_bird_timeout(timeout, deadline)
            if timeout is None:
                return _keep_best_partial(response, error, usable_count)
            continue
        chosen = _keep_best_partial(response, error, usable_count)
        return _annotate_session_error(chosen, error, failed_browser)


def _annotate_session_error(
    response: Dict[str, Any], error: str, failed_browser: Optional[str]
) -> Dict[str, Any]:
    """Name the browser whose X session failed so the report says what to fix."""
    error = _scrub_credentials(error)
    if not failed_browser:
        return {**response, "error": error} if "error" in response else response
    if _session_rejected(error):
        return {
            **response,
            "error": (
                f"X session rejected (cookies from {failed_browser}): {error}. "
                f"Log in to x.com again in {failed_browser}, or set FROM_BROWSER "
                "to the browser you use for X."
            ),
        }
    return {
        **response,
        "error": (
            f"{error} (X can return this when the {failed_browser} session "
            f"is expired; if it persists, log in to x.com again in "
            f"{failed_browser} or set FROM_BROWSER to the browser you use for X)"
        ),
    }


def _session_browser_update(browser: str) -> None:
    global _session_browser
    _session_browser = browser


def _run_bird_search_once(
    query: str,
    count: int,
    timeout: int,
    deadline: Optional[float] = None,
    cancel: Any = None,
    top: bool = False,
) -> Dict[str, Any]:
    """Run a search using the vendored bird-search.mjs module.

    Retries the subprocess on JSON-decode failure (typically a Twitter
    anti-bot HTML interstitial in stdout) up to MAX_JSON_DECODE_RETRIES
    times with JSON_DECODE_RETRY_DELAY seconds between attempts. Terminal
    errors (subprocess timeout, non-zero return code) are returned
    immediately without retry.

    Args:
        query: Full search query string (including since: filter)
        count: Number of results to request
        timeout: Timeout in seconds (per attempt)
        deadline: Optional shared ``time.monotonic()`` deadline. A decode
            retry runs only when the delay plus at least one second of
            subprocess time still fits; its timeout is re-clamped after the
            delay.

    Returns:
        Raw Bird JSON response or error dict.
    """
    last_decode_error: Optional[str] = None
    attempt_timeout: Optional[int] = timeout

    for attempt in range(MAX_JSON_DECODE_RETRIES):
        if cancel is not None and cancel.is_set():
            return {"error": "bird: research cancelled", "items": []}
        if attempt > 0:
            attempt_timeout = _clamped_bird_timeout(timeout, deadline)
            if attempt_timeout is None:
                return _invalid_json_error(
                    attempt, last_decode_error, budget_exhausted=True,
                )
        result, terminal_error = _invoke_bird_subprocess(
            query,
            count,
            attempt_timeout,
            top=top,
            deadline=deadline,
            cancel=cancel,
        )
        if terminal_error is not None:
            return terminal_error

        output = result.stdout.strip()
        if result.returncode != 0:
            if not output:
                error = _scrub_credentials(result.stderr.strip()) or "Bird search failed"
                return {"error": error, "items": []}
            # Windows/Node 24: the vendored Bird CLI uses native fetch (undici),
            # and calling process.exit() while keep-alive sockets are still
            # closing trips a libuv assertion -> non-zero exit code AFTER it has
            # already written a complete, valid JSON result to stdout. Trust
            # stdout when it has content; only treat a non-zero exit as a real
            # failure when stdout is empty.

        if not output:
            return {"items": []}

        try:
            parsed = json.loads(output)
        except json.JSONDecodeError as e:
            # Twitter's edge sometimes serves an HTML anti-bot interstitial
            # in place of JSON. Tag the failure shape so it's distinguishable
            # from "no results" in logs, then retry the subprocess.
            looks_html = output.lstrip().lower().startswith(("<!doctype", "<html", "<"))
            attempt_num = attempt + 1
            scrubbed_output = _scrub_credentials(output)
            log_msg = (
                f"Bird search returned non-JSON stdout "
                f"(looks_html={looks_html}, attempt {attempt_num}/{MAX_JSON_DECODE_RETRIES}, "
                f"first 80 chars: {scrubbed_output[:80]!r})"
            )
            last_decode_error = _scrub_credentials(str(e))
            if attempt_num < MAX_JSON_DECODE_RETRIES:
                if deadline is not None and (
                    deadline - time.monotonic() < JSON_DECODE_RETRY_DELAY + 1
                ):
                    log.source_log(
                        "X/bird",
                        f"{log_msg}; retry skipped, chain budget exhausted",
                        tty_only=False,
                    )
                    return _invalid_json_error(
                        attempt_num, last_decode_error, budget_exhausted=True,
                    )
                log.source_log(
                    "X/bird",
                    f"{log_msg}; retrying in {JSON_DECODE_RETRY_DELAY:.0f}s",
                    tty_only=False,
                )
                if cancel is not None:
                    cancel.wait(JSON_DECODE_RETRY_DELAY)
                else:
                    time.sleep(JSON_DECODE_RETRY_DELAY)
                continue
            log.source_log("X/bird", log_msg, tty_only=False)
            return _invalid_json_error(attempt_num, last_decode_error)

        if isinstance(parsed, list):
            return {"items": parsed}
        if isinstance(parsed, dict) and parsed.get("error"):
            return {**parsed, "error": _scrub_credentials(str(parsed["error"]))}
        return parsed

    # Defensive fallthrough — loop should always return above.
    return {
        "error": f"Bird search exhausted retries: {last_decode_error}",
        "items": [],
    }


def _clamped_bird_timeout(base: int, deadline: Optional[float]) -> Optional[int]:
    """Per-attempt timeout clamped to the chain's remaining budget.

    Returns None when the deadline already passed so the caller skips the
    subprocess instead of starting a call guaranteed to overrun the chain.
    """
    if deadline is None:
        return base
    remaining = deadline - time.monotonic()
    if remaining < 1:
        return None
    return max(1, min(base, int(remaining)))


def _budget_stop(
    response: Dict[str, Any],
    last_clean_response: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Outcome when an optional zero-result retry no longer fits the budget.

    A clean empty response stays a no-results outcome with a coverage warning;
    otherwise the earlier search's own error (interstitial, timeout) is more
    diagnostic than a generic budget message.
    """
    _log("chain budget exhausted; skipping remaining zero-result retries")
    if last_clean_response is not None:
        return {
            **last_clean_response,
            "warning": "Partial coverage: optional zero-result retries skipped because the search budget was exhausted.",
        }
    return response


def search_x(
    topic: str,
    from_date: str,
    to_date: str,
    depth: str = "default",
    deadline: Optional[float] = None,
    cancel: Any = None,
) -> Dict[str, Any]:
    """Search X using Bird CLI with automatic retry on 0 results.

    Args:
        topic: Search topic
        from_date: Start date (YYYY-MM-DD)
        to_date: Inclusive end date (YYYY-MM-DD)
        depth: Research depth - "quick", "default", or "deep"
        deadline: Optional shared wall-clock deadline (``time.monotonic()``
            instant) from the X backend chain. Each of the up-to-four
            sequential searches clamps its per-attempt timeout to the time
            left; searches past the deadline never start.

    Returns:
        Raw Bird JSON response or error dict.
    """
    count = DEPTH_CONFIG.get(depth, DEPTH_CONFIG["default"])
    search_kwargs = {"cancel": cancel} if cancel is not None else {}
    # Topic searches read X's Top tab. Latest is a time-ordered feed, so on a
    # busy topic its first page is the last few minutes of zero-engagement
    # posts, and handle expansion then promotes whoever happened to post in
    # those minutes. Handle and mention searches keep Latest for coverage.
    search_kwargs["top"] = True
    base_timeout = 30 if depth == "quick" else 45 if depth == "default" else 60
    timeout = _clamped_bird_timeout(base_timeout, deadline)
    if timeout is None:
        return {"error": "bird: chain budget exhausted", "items": []}

    terms = _topic_query_terms(topic)
    # Protect literal phrases from the shared subject extractor's casing,
    # noise filtering, and word cap.
    phrases = {}
    protected_terms = []
    for index, term in enumerate(terms):
        if term.startswith('"'):
            marker = f"{_PHRASE_MARKER}{index}"
            phrases[marker] = term
            term = marker
        protected_terms.append(term)
    core_subject = _extract_core_subject(" ".join(protected_terms))
    core_terms = _topic_query_terms(" ".join(phrases.get(word, word) for word in core_subject.split()))
    exact_phrases = list(phrases.values())
    retry_keywords = exact_phrases + [term for term in core_terms if not term.startswith('"')]
    core_topic = " ".join(core_terms).replace('"', "")
    date_filters = _date_filters(from_date, to_date)
    query = _fit_query(core_terms, date_filters)
    if not query:
        return {"error": "bird: no searchable keywords fit the topic query", "items": []}

    _log(f"Searching: {query}")
    response = _run_bird_search(query, count, timeout, deadline=deadline, **search_kwargs)
    last_clean_response = response if not response.get("error") else None

    # Check if we got results
    items = parse_bird_response(response, query=core_topic)

    # Retry with OR groups for multi-word queries (X supports OR operator)
    if not items and len(core_terms) >= 2:
        from .query import extract_compound_terms
        alternatives = exact_phrases
        if not alternatives:
            compounds = extract_compound_terms(" ".join(terms))
            alternatives = ['"' + term.strip('"') + '"' for term in compounds]
        query = _fit_query(alternatives[:3], date_filters, disjunction=True)
        if query:
            _log(f"0 results for '{core_topic}', retrying with OR groups: {query}")
            timeout = _clamped_bird_timeout(base_timeout, deadline)
            if timeout is None:
                return _budget_stop(response, last_clean_response)
            response = _run_bird_search(query, count, timeout, deadline=deadline, **search_kwargs)
            if not response.get("error"):
                last_clean_response = response
            items = parse_bird_response(response, query=core_topic)

    # Retry with fewer keywords if still 0 results and query has 3+ words
    query = ""
    if not items and len(retry_keywords) > 2:
        query = _fit_query(retry_keywords[:2], date_filters)
    if query:
        _log(f"0 results for '{core_topic}', retrying with '{query}'")
        timeout = _clamped_bird_timeout(base_timeout, deadline)
        if timeout is None:
            return _budget_stop(response, last_clean_response)
        response = _run_bird_search(query, count, timeout, deadline=deadline, **search_kwargs)
        if not response.get("error"):
            last_clean_response = response
        items = parse_bird_response(response, query=core_topic)

    # Last-chance retry: use strongest remaining token (often the product name)
    if not items:
        low_signal = {
            'trendiest', 'trending', 'hottest', 'hot', 'popular', 'viral',
            'best', 'top', 'latest', 'new', 'plugin', 'plugins',
            'skill', 'skills', 'tool', 'tools',
        }
        candidates = [term for term in retry_keywords if term not in low_signal]
        query = ""
        if candidates:
            # Keep an entity anchor (the first distinctive topic token) in the
            # retry so it can't collapse to a bare generic token like "compound"
            # and flood the X pool with off-topic noise. Add the strongest
            # (longest) distinctive token when it differs from the anchor;
            # otherwise query the anchor alone. Better to return 0 than to
            # over-broaden to an unanchored generic term.
            anchor = candidates[0]
            strongest = max(candidates, key=len)
            anchored_terms = [anchor] if strongest == anchor else [anchor, strongest]
            query = _fit_query(anchored_terms, date_filters)
        if query:
            _log(f"0 results for '{core_topic}', retrying anchored on '{query}'")
            timeout = _clamped_bird_timeout(base_timeout, deadline)
            if timeout is None:
                return _budget_stop(response, last_clean_response)
            response = _run_bird_search(query, count, timeout, deadline=deadline, **search_kwargs)
            if not response.get("error"):
                last_clean_response = response
            items = parse_bird_response(response, query=core_topic)

    if cancel is not None and cancel.is_set():
        return {**response, "error": "bird: research cancelled"}
    if response.get("error") and not items and last_clean_response is not None:
        _log("Optional retry failed after a clean empty response; preserving no-results outcome")
        return last_clean_response
    return response


def search_handles(
    handles: List[str],
    topic: Optional[str],
    from_date: str,
    count_per: int = 5,
    failure_out: Optional[List[str]] = None,
    *,
    to_date: Optional[str] = None,
    deadline: Optional[float] = None,
    cancel: Any = None,
) -> List[Dict[str, Any]]:
    """Search specific X handles for topic-related content.

    Pulls each handle's actual timeline via `from:handle since:` — the FROM
    lane (tweets BY the person), engagement-weighted downstream. The topic is
    used for relevance RANKING, never AND'd into the query: X search is literal,
    so `from:handle <their name>` only matched tweets where they wrote their own
    name and returned ~0. Used in Phase 2 after entity extraction.

    Args:
        handles: List of X handles to search (without @)
        topic: Search topic — used for relevance ranking only, not the query
        from_date: Start date (YYYY-MM-DD)
        count_per: Results to request per handle
        failure_out: When provided, a short reason is appended for every
            per-handle failure branch, so the caller can distinguish a
            transport failure from a handle that genuinely posted nothing.
        to_date: Inclusive end date (YYYY-MM-DD), when supplied

    Returns:
        List of raw item dicts (same format as parse_bird_response output).
    """
    if not handles:
        return []
    core_topic = _extract_core_subject(topic) if topic else None
    date_filters = _date_filters(from_date, to_date)

    def _note(msg: str) -> None:
        if failure_out is not None:
            failure_out.append(msg)

    def _search_one_handle(handle: str) -> List[Dict[str, Any]]:
        timeout = _clamped_bird_timeout(15, deadline)
        if timeout is None or (cancel is not None and cancel.is_set()):
            _note("bird handle research cancelled or timed out")
            return []
        handle = handle.lstrip("@")
        # Always unfiltered: pull the timeline, rank by topic relevance below.
        query = f"from:{handle} {date_filters}"

        timeout_ms = _bird_timeout_ms(timeout, deadline)
        cmd = [
            "node", str(_BIRD_SEARCH_MJS),
            "--count", str(count_per),
            "--timeout-ms", str(timeout_ms),
            "--json",
            "--",
            query,
        ]

        try:
            result = subproc.run_with_timeout(
                cmd,
                timeout=timeout,
                env=_subprocess_env(),
                cancel=cancel,
                deadline_monotonic=deadline,
                capture_limit_bytes=_BIRD_CAPTURE_LIMIT_BYTES,
            )
        except subproc.SubprocTimeout:
            if cancel is not None and cancel.is_set():
                _log(f"Handle search cancelled for @{handle}")
                _note(f"@{handle}: bird-search cancelled")
            else:
                _log(f"Handle search timed out for @{handle}")
                _note(f"@{handle}: bird-search timed out after {timeout}s")
            return []
        except OSError as e:
            err = _scrub_credentials(str(e))
            _log(f"Handle search error for @{handle}: {err}")
            _note(f"@{handle}: could not spawn bird-search ({err})")
            return []

        output = result.stdout.strip()
        if result.returncode != 0:
            if not output:
                _log(f"Handle search failed for @{handle}: {_scrub_credentials(result.stderr.strip())}")
                _note(
                    f"@{handle}: bird-search exited {result.returncode} "
                    f"({_scrub_credentials(result.stderr.strip())[:160] or 'no stderr'})"
                )
                return []
            # Windows/Node 24 benign libuv assertion or partial-page JSON error:
            # stdout carries the JSON payload.

        if not output:
            return []

        try:
            response = json.loads(output)
        except json.JSONDecodeError:
            _log(f"Invalid JSON from handle search for @{handle}")
            _note(f"@{handle}: bird-search returned invalid JSON")
            return []
        if isinstance(response, dict) and response.get("error"):
            err = _scrub_credentials(str(response["error"]))
            _log(f"Handle search error for @{handle}: {err}")
            _note(f"@{handle}: {err[:160]}")
        items = parse_bird_response(response, query=core_topic)
        # Log on success/empty too (not only on failure): a silent handle search
        # made the from: query look like it never ran and caused wrong diagnoses.
        _log(f"Searching: {query} -> {len(items)} results")
        return items

    from concurrent.futures import ThreadPoolExecutor, as_completed

    all_items: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(5, len(handles))) as executor:
        futures = {executor.submit(_search_one_handle, h): h for h in handles}
        for future in as_completed(futures):
            all_items.extend(future.result())

    return all_items


def search_mentions(
    handles: List[str],
    from_date: str,
    count_per: int = 5,
    failure_out: Optional[List[str]] = None,
    *,
    to_date: Optional[str] = None,
    deadline: Optional[float] = None,
    cancel: Any = None,
) -> List[Dict[str, Any]]:
    """Search for tweets ABOUT/TO each handle — the mention lane.

    Queries `@handle since:` (tweets that mention the account) and excludes the
    handle's OWN tweets (those belong to the FROM lane via search_handles), so
    this surfaces what OTHERS are saying about the person. Engagement-weighted
    downstream; deduped against the FROM lane by URL at normalize time.

    Args:
        handles: List of X handles (without @)
        from_date: Start date (YYYY-MM-DD)
        count_per: Results to request per handle
        failure_out: When provided, a short reason is appended for every
            per-handle failure branch, so the caller can distinguish a
            transport failure from a handle nobody mentioned.
        to_date: Inclusive end date (YYYY-MM-DD), when supplied

    Returns:
        List of raw item dicts (same format as parse_bird_response output).
    """
    if not handles:
        return []
    date_filters = _date_filters(from_date, to_date)

    def _note(msg: str) -> None:
        if failure_out is not None:
            failure_out.append(msg)

    def _search_one(handle: str) -> List[Dict[str, Any]]:
        timeout = _clamped_bird_timeout(15, deadline)
        if timeout is None or (cancel is not None and cancel.is_set()):
            _note("bird mention research cancelled or timed out")
            return []
        handle = handle.lstrip("@")
        query = f"@{handle} {date_filters}"
        timeout_ms = _bird_timeout_ms(timeout, deadline)
        cmd = [
            "node", str(_BIRD_SEARCH_MJS),
            "--count", str(count_per),
            "--timeout-ms", str(timeout_ms),
            "--json",
            "--",
            query,
        ]
        try:
            result = subproc.run_with_timeout(
                cmd,
                timeout=timeout,
                env=_subprocess_env(),
                cancel=cancel,
                deadline_monotonic=deadline,
                capture_limit_bytes=_BIRD_CAPTURE_LIMIT_BYTES,
            )
        except subproc.SubprocTimeout:
            if cancel is not None and cancel.is_set():
                _log(f"Mention search cancelled for @{handle}")
                _note(f"@{handle}: bird-search cancelled")
            else:
                _log(f"Mention search timed out for @{handle}")
                _note(f"@{handle}: bird-search timed out after {timeout}s")
            return []
        except OSError as e:
            err = _scrub_credentials(str(e))
            _log(f"Mention search error for @{handle}: {err}")
            _note(f"@{handle}: could not spawn bird-search ({err})")
            return []
        output = result.stdout.strip()
        if result.returncode != 0:
            if not output:
                _log(f"Mention search failed for @{handle}: {_scrub_credentials(result.stderr.strip())}")
                _note(
                    f"@{handle}: bird-search exited {result.returncode} "
                    f"({_scrub_credentials(result.stderr.strip())[:160] or 'no stderr'})"
                )
                return []
            # Windows/Node 24 benign libuv assertion or partial-page JSON error:
            # stdout carries the JSON payload.
        if not output:
            return []
        try:
            response = json.loads(output)
        except json.JSONDecodeError:
            _log(f"Invalid JSON from mention search for @{handle}")
            _note(f"@{handle}: bird-search returned invalid JSON")
            return []
        if isinstance(response, dict) and response.get("error"):
            err = _scrub_credentials(str(response["error"]))
            _log(f"Mention search error for @{handle}: {err}")
            _note(f"@{handle}: {err[:160]}")
        items = parse_bird_response(response, query=None)
        # ABOUT lane = OTHERS mentioning the handle. Drop the handle's own tweets
        # (the FROM lane already covers those); identify by the status URL author.
        hl = handle.lower()
        # The Bird API may return either x.com or twitter.com permalinks, so
        # match both when excluding the handle's own tweets.
        def _is_own(url):
            u = (url or "").lower()
            return f"x.com/{hl}/status" in u or f"twitter.com/{hl}/status" in u
        about = [it for it in items if not _is_own(it.get("url"))]
        _log(f"Searching: {query} -> {len(about)} mentions")
        return about

    from concurrent.futures import ThreadPoolExecutor, as_completed

    all_items: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(5, len(handles))) as executor:
        futures = {executor.submit(_search_one, h): h for h in handles}
        for future in as_completed(futures):
            all_items.extend(future.result())
    return all_items


def parse_bird_response(response: Dict[str, Any], query: str = "") -> List[Dict[str, Any]]:
    """Parse Bird response to match xai_x output format.

    Args:
        response: Raw Bird JSON response
        query: Original search query for relevance scoring

    Returns:
        List of normalized item dicts matching xai_x.parse_x_response() format.
    """
    items = []

    # Log any reported error (scrubbed), while still parsing partial items when
    # a multi-page search succeeded on page 1 before failing on page 2+.
    if isinstance(response, dict) and "error" in response and response["error"]:
        _log(f"Bird error: {_scrub_credentials(str(response['error']))}")

    # Bird returns a list of tweets directly or under a key
    raw_items = response if isinstance(response, list) else (
        response.get("items", response.get("tweets", [])) if isinstance(response, dict) else []
    )

    if not isinstance(raw_items, list):
        return items

    for i, tweet in enumerate(raw_items):
        if not isinstance(tweet, dict):
            continue

        # Extract URL - Bird uses permanent_url or we construct from id
        url = tweet.get("permanent_url") or tweet.get("url", "")
        if not url and tweet.get("id"):
            # Try different field structures Bird might use
            author = tweet.get("author", {}) or tweet.get("user", {})
            screen_name = author.get("username") or author.get("screen_name", "")
            if screen_name:
                url = f"https://x.com/{screen_name}/status/{tweet['id']}"

        if not url:
            continue

        # Parse date from created_at/createdAt (e.g., "Wed Jan 15 14:30:00 +0000 2026")
        date = None
        created_at = tweet.get("createdAt") or tweet.get("created_at", "")
        if created_at:
            try:
                # Try ISO format first (e.g., "2026-02-03T22:33:32Z")
                # Check for ISO date separator, not just "T" (which appears in "Tue")
                if len(created_at) > 10 and created_at[10] == "T":
                    dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                else:
                    # Twitter format: "Wed Jan 15 14:30:00 +0000 2026"
                    dt = datetime.strptime(created_at, "%a %b %d %H:%M:%S %z %Y")
                date = dt.strftime("%Y-%m-%d")
            except (ValueError, TypeError):
                pass

        # Extract user info (Bird uses author.username, older format uses user.screen_name)
        author = tweet.get("author", {}) or tweet.get("user", {})
        author_handle = author.get("username") or author.get("screen_name", "") or tweet.get("author_handle", "")

        # Build engagement dict (Bird uses camelCase: likeCount, retweetCount, etc.)
        engagement = {
            "likes": _first_of(tweet.get("likeCount"), tweet.get("like_count"), tweet.get("favorite_count")),
            "reposts": _first_of(tweet.get("retweetCount"), tweet.get("retweet_count")),
            "replies": _first_of(tweet.get("replyCount"), tweet.get("reply_count")),
            "quotes": _first_of(tweet.get("quoteCount"), tweet.get("quote_count")),
        }
        # Convert to int where possible
        for key in engagement:
            if engagement[key] is not None:
                try:
                    engagement[key] = int(engagement[key])
                except (ValueError, TypeError):
                    engagement[key] = None

        # Build normalized item
        text = str(tweet.get("text", tweet.get("full_text", ""))).strip()[:500]
        item = {
            "id": f"X{i+1}",
            "text": text,
            "url": url,
            "author_handle": author_handle.lstrip("@"),
            # Leading @mentions parsed from the post text identify who a reply is
            # directed at (X replies open with the target handle(s)). Used by the
            # interaction-signal classifier in rerank.
            "mentioned_handles": _leading_mentions(text),
            "date": date,
            "engagement": engagement if any(v is not None for v in engagement.values()) else None,
            "why_relevant": "",  # Bird doesn't provide relevance explanations
            "relevance": _compute_relevance(query, str(tweet.get("text", ""))) if query else 0.7,
        }

        items.append(item)

    return items
